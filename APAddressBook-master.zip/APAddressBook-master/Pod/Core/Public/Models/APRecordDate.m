//
//  APRecordDate
//  APAddressBook
//
//  Created by Alexey Belkevich on 05.10.15.
//  Copyright © 2015 alterplay. All rights reserved.
//

#import "APRecordDate.h"

@implementation APRecordDate
@end