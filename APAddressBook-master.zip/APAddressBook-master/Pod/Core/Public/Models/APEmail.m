//
//  APEmail.m
//  APAddressBook
//
//  Created by Sean Langley on 2015-03-18.
//  Copyright (c) 2015 Sean Langley. All rights reserved.
//

#import "APEmail.h"

@implementation APEmail

@end
